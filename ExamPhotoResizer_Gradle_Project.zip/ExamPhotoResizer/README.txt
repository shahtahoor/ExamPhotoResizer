EXAM PHOTO RESIZER - ANDROID GRADLE PROJECT

Open this project in Android Studio:
1. Extract ExamPhotoResizer.zip.
2. In Android Studio choose File > Open and select the extracted ExamPhotoResizer folder.
3. Allow Gradle sync and install any SDK components Android Studio requests.
4. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show a notification with a link to the generated APK.

The app wraps the included HTML tool in an Android WebView. The background-removal
feature loads MediaPipe Selfie Segmentation from a CDN, so internet access is needed
for that feature. Photo cropping and resizing are performed locally in the WebView.
